This is for Assignment 1 of Network Application.
Adam Coyte
101127321

My Folder has 4 other files
client.py: has all the code for the client application to run it takes command line arguments  python client.py <IP> <PORT> <FILENAME>
server.py: Is the python script used to run the python server. It dynamicallys grabs an IP and uses port 5454 for hosting
text.file: the file used for testing, hold small string to ensure working
PROTOCOL.TXT: this file is used to describe my protocol for sending information from client to server and vice versa